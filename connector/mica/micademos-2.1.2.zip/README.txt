This is a binary release of Mica and FrameScript.

In the doc directory of this distribution you will find user documentation for both Mica and FrameScript.

Located in the bin directory are a number of executable scripts for starting the demos provided with this release. For descriptions of the demos look at "doc/Demos.pdf".

The source files for the demos can be found in the src directory and used resources in the resources directory. The demo scripts for simplicity however use the micademos.jar file for their binary code.

If you have any questions regarding Mica or FrameScript send an email to mmcgill@cse.unsw.edu.au